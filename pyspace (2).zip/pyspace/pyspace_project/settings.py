"""
Django settings for pyspace_project.

PySpace - an original, open-source social networking project inspired by
the customizable, personal feel of mid-2000s social networks.
"""

from pathlib import Path
from decouple import config, Csv

BASE_DIR = Path(__file__).resolve().parent.parent

# -----------------------------------------------------------------------
# Core / security
# -----------------------------------------------------------------------
SECRET_KEY = config('SECRET_KEY', default='django-insecure-change-me-in-production')
DEBUG = config('DEBUG', default=True, cast=bool)
ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1', cast=Csv())

# -----------------------------------------------------------------------
# Applications
# -----------------------------------------------------------------------
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',

    # Third-party
    'django.contrib.sitemaps',

    # PySpace apps
    'apps.accounts',
    'apps.profiles',
    'apps.friends',
    'apps.posts',
    'apps.comments',
    'apps.messaging',
    'apps.media',
    'apps.notifications',
    'apps.moderation',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'apps.moderation.middleware.RateLimitMiddleware',
]

ROOT_URLCONF = 'pyspace_project.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'apps.notifications.context_processors.notification_count',
            ],
        },
    },
]

WSGI_APPLICATION = 'pyspace_project.wsgi.application'

# -----------------------------------------------------------------------
# Database
# -----------------------------------------------------------------------
if config('DATABASE_URL', default=''):
    import dj_database_url
    DATABASES = {'default': dj_database_url.parse(config('DATABASE_URL'))}
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }

# -----------------------------------------------------------------------
# Auth
# -----------------------------------------------------------------------
AUTH_USER_MODEL = 'accounts.User'

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LOGIN_URL = 'accounts:login'
LOGIN_REDIRECT_URL = 'posts:feed'
LOGOUT_REDIRECT_URL = 'accounts:login'

# -----------------------------------------------------------------------
# Internationalization
# -----------------------------------------------------------------------
LANGUAGE_CODE = 'en-us'
TIME_ZONE = config('TIME_ZONE', default='UTC')
USE_I18N = True
USE_TZ = True

# -----------------------------------------------------------------------
# Static & media files
# -----------------------------------------------------------------------
STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = 'media/'
MEDIA_ROOT = BASE_DIR / 'mediafiles'

# Upload validation (used by apps.media)
MAX_UPLOAD_SIZE_MB = config('MAX_UPLOAD_SIZE_MB', default=8, cast=int)
ALLOWED_IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp']

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# -----------------------------------------------------------------------
# Security hardening (mostly relevant in production, gated by DEBUG)
# -----------------------------------------------------------------------
if not DEBUG:
    SECURE_SSL_REDIRECT = config('SECURE_SSL_REDIRECT', default=True, cast=bool)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    X_FRAME_OPTIONS = 'DENY'

CSRF_TRUSTED_ORIGINS = config('CSRF_TRUSTED_ORIGINS', default='', cast=Csv())

# -----------------------------------------------------------------------
# Email (used for password reset)
# -----------------------------------------------------------------------
EMAIL_BACKEND = config(
    'EMAIL_BACKEND',
    default='django.core.mail.backends.console.EmailBackend',
)
EMAIL_HOST = config('EMAIL_HOST', default='')
EMAIL_PORT = config('EMAIL_PORT', default=587, cast=int)
EMAIL_HOST_USER = config('EMAIL_HOST_USER', default='')
EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD', default='')
EMAIL_USE_TLS = config('EMAIL_USE_TLS', default=True, cast=bool)
DEFAULT_FROM_EMAIL = config('DEFAULT_FROM_EMAIL', default='noreply@pyspace.local')

# -----------------------------------------------------------------------
# PySpace-specific settings
# -----------------------------------------------------------------------
PYSPACE_ALLOWED_FONTS = [
    ('arial', 'Arial'),
    ('comic-sans', 'Comic Sans MS'),
    ('courier', 'Courier New'),
    ('georgia', 'Georgia'),
    ('impact', 'Impact'),
    ('papyrus', 'Papyrus'),
    ('times', 'Times New Roman'),
    ('verdana', 'Verdana'),
]

PYSPACE_ALLOWED_THEMES = [
    'classic-blue', 'hot-pink', 'neon-green', 'sunset-gradient',
    'midnight-purple', 'glitter-black', 'skater-punk', 'plain-white',
]
PYSPACE_MAX_FRIENDS_DISPLAY = 200
PYSPACE_POSTS_PER_PAGE = 20
PYSPACE_RATE_LIMIT_POSTS_PER_MINUTE = config('RATE_LIMIT_POSTS_PER_MINUTE', default=10, cast=int)
PYSPACE_RATE_LIMIT_COMMENTS_PER_MINUTE = config('RATE_LIMIT_COMMENTS_PER_MINUTE', default=20, cast=int)
