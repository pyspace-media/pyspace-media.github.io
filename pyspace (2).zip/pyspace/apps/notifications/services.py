from .models import Notification


def notify(recipient, actor, verb, target=None):
    """Create a notification, skipping self-notifications."""
    if recipient == actor:
        return None
    return Notification.objects.create(recipient=recipient, actor=actor, verb=verb, target=target)
