from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models


class Notification(models.Model):
    class Verb(models.TextChoices):
        FRIEND_REQUEST = 'friend_request', 'sent you a friend request'
        FRIEND_ACCEPT = 'friend_accept', 'accepted your friend request'
        COMMENT = 'comment', 'commented on your post'
        PROFILE_COMMENT = 'profile_comment', 'left a comment on your profile'
        LIKE = 'like', 'liked your post'
        MESSAGE = 'message', 'sent you a message'

    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications',
    )
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+',
    )
    verb = models.CharField(max_length=30, choices=Verb.choices)

    target_content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True, blank=True)
    target_object_id = models.PositiveIntegerField(null=True, blank=True)
    target = GenericForeignKey('target_content_type', 'target_object_id')

    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [models.Index(fields=['recipient', 'is_read'])]

    def __str__(self):
        return f"{self.actor} {self.get_verb_display()} -> {self.recipient}"
