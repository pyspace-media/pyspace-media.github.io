from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import Notification
from .services import notify


class NotificationTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')

    def test_notify_creates_notification(self):
        notify(self.bob, actor=self.alice, verb='friend_request')
        self.assertTrue(Notification.objects.filter(recipient=self.bob, actor=self.alice).exists())

    def test_notify_skips_self_notifications(self):
        result = notify(self.alice, actor=self.alice, verb='like')
        self.assertIsNone(result)
        self.assertFalse(Notification.objects.filter(recipient=self.alice, actor=self.alice).exists())

    def test_viewing_notifications_marks_them_read(self):
        Notification.objects.create(recipient=self.bob, actor=self.alice, verb='like')
        self.client.login(username='bob', password='pw12345678')
        self.client.get(reverse('notifications:list'))
        self.assertEqual(Notification.objects.filter(recipient=self.bob, is_read=False).count(), 0)
