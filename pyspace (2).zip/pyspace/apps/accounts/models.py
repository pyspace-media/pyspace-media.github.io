import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse


class User(AbstractUser):
    """
    Custom user model for PySpace.

    We extend AbstractUser (rather than AbstractBaseUser) so we keep
    Django's battle-tested auth machinery, but add the fields PySpace
    needs: a public UUID, a unique profile slug, and basic privacy /
    account-state flags.
    """

    class PrivacyLevel(models.TextChoices):
        PUBLIC = 'public', 'Public - anyone can view'
        FRIENDS_ONLY = 'friends', 'Friends only'
        PRIVATE = 'private', 'Private - only me'

    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    # `username` already exists on AbstractUser and is already unique;
    # we reuse it as the profile slug (e.g. /u/<username>/) so we don't
    # duplicate a second "handle" field.
    email = models.EmailField(unique=True)

    profile_privacy = models.CharField(
        max_length=10, choices=PrivacyLevel.choices, default=PrivacyLevel.PUBLIC,
        help_text="Who can view your full profile.",
    )
    friends_list_privacy = models.CharField(
        max_length=10, choices=PrivacyLevel.choices, default=PrivacyLevel.PUBLIC,
        help_text="Who can view your friends list.",
    )

    is_deactivated = models.BooleanField(default=False)
    is_banned = models.BooleanField(default=False)
    ban_reason = models.CharField(max_length=255, blank=True)

    email_verified = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)

    REQUIRED_FIELDS = ['email']

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.username

    def get_absolute_url(self):
        return reverse('profiles:detail', kwargs={'username': self.username})

    @property
    def is_active_and_visible(self):
        return self.is_active and not self.is_deactivated and not self.is_banned
