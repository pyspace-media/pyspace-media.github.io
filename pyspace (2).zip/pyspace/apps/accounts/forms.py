import re

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

from .models import User

USERNAME_RE = re.compile(r'^[a-zA-Z0-9_]{3,30}$')

# A short reserved list so people can't grab URLs that collide with
# real site sections (e.g. /u/admin/, /u/login/).
RESERVED_USERNAMES = {
    'admin', 'administrator', 'root', 'login', 'logout', 'register',
    'signup', 'signin', 'settings', 'help', 'support', 'staff',
    'moderator', 'mod', 'api', 'static', 'media', 'pyspace', 'about',
    'terms', 'privacy', 'null', 'undefined', 'me', 'you',
}


class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True, help_text="Used for login recovery only, never shown publicly.")

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_username(self):
        username = self.cleaned_data['username'].strip()
        if not USERNAME_RE.match(username):
            raise ValidationError(
                "Usernames must be 3-30 characters and can only contain "
                "letters, numbers, and underscores."
            )
        if username.lower() in RESERVED_USERNAMES:
            raise ValidationError("That username is reserved. Please choose another.")
        if User.objects.filter(username__iexact=username).exists():
            raise ValidationError("That username is already taken.")
        return username

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError("An account with that email already exists.")
        return email


class AccountSettingsForm(forms.ModelForm):
    """Basic account settings: email + privacy defaults."""

    class Meta:
        model = User
        fields = ['email', 'profile_privacy', 'friends_list_privacy']

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
            raise ValidationError("An account with that email already exists.")
        return email


class DeactivateAccountForm(forms.Form):
    confirm = forms.BooleanField(
        required=True,
        label="I understand my profile will be hidden until I log back in.",
    )
    password = forms.CharField(widget=forms.PasswordInput)
