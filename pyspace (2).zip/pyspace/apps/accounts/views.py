from django.contrib import messages
from django.contrib.auth import login, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView as DjangoLoginView
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.generic import CreateView

from apps.profiles.models import Profile

from .forms import AccountSettingsForm, DeactivateAccountForm, RegistrationForm
from .models import User


class RegisterView(CreateView):
    model = User
    form_class = RegistrationForm
    template_name = 'accounts/register.html'

    def form_valid(self, form):
        response = super().form_valid(form)
        # A profile is created automatically via the post_save signal in
        # apps.profiles.signals, so we don't create one here.
        login(self.request, self.object)
        messages.success(self.request, f"Welcome to PySpace, {self.object.username}! Your page is ready to customize.")
        return response

    def get_success_url(self):
        return '/'


class LoginView(DjangoLoginView):
    template_name = 'accounts/login.html'
    redirect_authenticated_user = True

    def form_valid(self, form):
        response = super().form_valid(form)
        user = form.get_user()
        if user.is_banned:
            from django.contrib.auth import logout
            logout(self.request)
            messages.error(self.request, f"This account has been banned. Reason: {user.ban_reason or 'policy violation'}")
            return redirect('accounts:login')
        user.is_deactivated = False
        user.last_seen_at = timezone.now()
        user.save(update_fields=['is_deactivated', 'last_seen_at'])
        return response


@login_required
def account_settings(request):
    if request.method == 'POST':
        form = AccountSettingsForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Account settings updated.")
            return redirect('accounts:settings')
    else:
        form = AccountSettingsForm(instance=request.user)
    return render(request, 'accounts/settings.html', {'form': form})


@login_required
def deactivate_account(request):
    if request.method == 'POST':
        form = DeactivateAccountForm(request.POST)
        if form.is_valid():
            if request.user.check_password(form.cleaned_data['password']):
                request.user.is_deactivated = True
                request.user.save(update_fields=['is_deactivated'])
                from django.contrib.auth import logout
                logout(request)
                messages.info(request, "Your account has been deactivated. Log back in any time to reactivate it.")
                return redirect('accounts:login')
            form.add_error('password', 'Incorrect password.')
    else:
        form = DeactivateAccountForm()
    return render(request, 'accounts/deactivate.html', {'form': form})
