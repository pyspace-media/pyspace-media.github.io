from django.test import TestCase
from django.urls import reverse

from .models import User


class RegistrationTests(TestCase):
    def test_register_creates_user_and_logs_in(self):
        response = self.client.post(reverse('accounts:register'), {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password1': 'Sup3rSecret!23',
            'password2': 'Sup3rSecret!23',
        }, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(User.objects.filter(username='newuser').exists())
        self.assertTrue(response.context['user'].is_authenticated)

    def test_duplicate_username_rejected(self):
        User.objects.create_user(username='taken', email='a@example.com', password='pw12345678')
        response = self.client.post(reverse('accounts:register'), {
            'username': 'taken',
            'email': 'b@example.com',
            'password1': 'Sup3rSecret!23',
            'password2': 'Sup3rSecret!23',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'already taken')

    def test_reserved_username_rejected(self):
        response = self.client.post(reverse('accounts:register'), {
            'username': 'admin',
            'email': 'c@example.com',
            'password1': 'Sup3rSecret!23',
            'password2': 'Sup3rSecret!23',
        })
        self.assertContains(response, 'reserved')


class LoginTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='logintest', email='lt@example.com', password='Sup3rSecret!23')

    def test_login_success(self):
        response = self.client.post(reverse('accounts:login'), {
            'username': 'logintest', 'password': 'Sup3rSecret!23',
        }, follow=True)
        self.assertTrue(response.context['user'].is_authenticated)

    def test_banned_user_cannot_log_in(self):
        self.user.is_banned = True
        self.user.ban_reason = 'testing'
        self.user.save()
        response = self.client.post(reverse('accounts:login'), {
            'username': 'logintest', 'password': 'Sup3rSecret!23',
        }, follow=True)
        self.assertFalse(response.context['user'].is_authenticated)
