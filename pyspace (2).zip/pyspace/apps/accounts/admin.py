from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import User


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ('username', 'email', 'is_active', 'is_banned', 'is_deactivated', 'date_joined')
    list_filter = ('is_active', 'is_banned', 'is_deactivated', 'is_staff')
    search_fields = ('username', 'email')
    actions = ['ban_users', 'unban_users']

    fieldsets = DjangoUserAdmin.fieldsets + (
        ('PySpace account state', {
            'fields': ('public_id', 'is_deactivated', 'is_banned', 'ban_reason', 'email_verified'),
        }),
        ('Privacy', {
            'fields': ('profile_privacy', 'friends_list_privacy'),
        }),
    )
    readonly_fields = ('public_id', 'created_at', 'updated_at', 'last_seen_at')

    @admin.action(description="Ban selected users")
    def ban_users(self, request, queryset):
        queryset.update(is_banned=True)

    @admin.action(description="Unban selected users")
    def unban_users(self, request, queryset):
        queryset.update(is_banned=False, ban_reason='')
