from django.contrib import admin

from .models import Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'display_name', 'theme', 'view_count', 'updated_at')
    search_fields = ('user__username', 'display_name')
    list_filter = ('theme', 'font_choice')
