from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render

from .forms import ProfileCustomizationForm, ProfileInfoForm
from .models import Profile

User = get_user_model()


def profile_detail(request, username):
    user = get_object_or_404(User, username__iexact=username)
    profile = user.profile

    if not user.is_active_and_visible and request.user != user:
        raise Http404("This profile is not available.")

    can_view = _can_view_profile(request.user, user)
    if not can_view:
        return render(request, 'profiles/private_profile.html', {'profile_user': user}, status=403)

    # Only count views from other people, not the owner refreshing their own page.
    if request.user != user:
        Profile.objects.filter(pk=profile.pk).update(view_count=profile.view_count + 1)

    from apps.friends.models import Friendship
    from apps.posts.models import Post
    from apps.comments.models import ProfileComment

    friends_qs = Friendship.objects.friends_of(user)
    is_friend = request.user.is_authenticated and Friendship.objects.are_friends(request.user, user)

    context = {
        'profile_user': user,
        'profile': profile,
        'friends': friends_qs[:24],
        'friends_count': friends_qs.count(),
        'is_own_profile': request.user == user,
        'is_friend': is_friend,
        'posts': Post.objects.filter(author=user).order_by('-created_at')[:20],
        'profile_comments': ProfileComment.objects.filter(profile_owner=user).order_by('-created_at')[:20],
    }
    return render(request, 'profiles/detail.html', context)


def _can_view_profile(viewer, profile_owner):
    if viewer == profile_owner:
        return True
    privacy = profile_owner.profile_privacy
    if privacy == 'public':
        return True
    if not viewer.is_authenticated:
        return False
    if privacy == 'friends':
        from apps.friends.models import Friendship
        return Friendship.objects.are_friends(viewer, profile_owner)
    return False  # private


@login_required
def edit_profile_info(request):
    profile = request.user.profile
    if request.method == 'POST':
        form = ProfileInfoForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated!")
            return redirect('profiles:detail', username=request.user.username)
    else:
        form = ProfileInfoForm(instance=profile)
    return render(request, 'profiles/edit_info.html', {'form': form})


@login_required
def edit_profile_customization(request):
    profile = request.user.profile
    if request.method == 'POST':
        form = ProfileCustomizationForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Your page's look has been updated!")
            return redirect('profiles:detail', username=request.user.username)
    else:
        form = ProfileCustomizationForm(instance=profile)
    return render(request, 'profiles/edit_customization.html', {'form': form, 'preview_profile': profile})


def browse_users(request):
    query = request.GET.get('q', '').strip()
    users = User.objects.filter(is_active=True, is_deactivated=False, is_banned=False)
    if query:
        users = users.filter(Q(username__icontains=query) | Q(profile__display_name__icontains=query))
    users = users.order_by('-date_joined')[:60]
    return render(request, 'profiles/browse.html', {'users': users, 'query': query})
