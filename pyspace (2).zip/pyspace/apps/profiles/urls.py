from django.urls import path

from . import views

app_name = 'profiles'

urlpatterns = [
    path('', views.browse_users, name='browse'),
    path('edit/info/', views.edit_profile_info, name='edit_info'),
    path('edit/customize/', views.edit_profile_customization, name='edit_customization'),
    path('<str:username>/', views.profile_detail, name='detail'),
]
