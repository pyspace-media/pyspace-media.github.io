from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import Profile


class ProfileAutoCreationTests(TestCase):
    def test_profile_created_on_user_creation(self):
        user = User.objects.create_user(username='u1', email='u1@example.com', password='pw12345678')
        self.assertTrue(Profile.objects.filter(user=user).exists())


class ProfileVisibilityTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(username='owner', email='o@example.com', password='pw12345678')
        self.stranger = User.objects.create_user(username='stranger', email='s@example.com', password='pw12345678')

    def test_public_profile_visible_to_anyone(self):
        response = self.client.get(reverse('profiles:detail', kwargs={'username': 'owner'}))
        self.assertEqual(response.status_code, 200)

    def test_private_profile_hidden_from_non_friends(self):
        self.owner.profile_privacy = User.PrivacyLevel.PRIVATE
        self.owner.save()
        self.client.login(username='stranger', password='pw12345678')
        response = self.client.get(reverse('profiles:detail', kwargs={'username': 'owner'}))
        self.assertEqual(response.status_code, 403)

    def test_owner_can_always_view_own_private_profile(self):
        self.owner.profile_privacy = User.PrivacyLevel.PRIVATE
        self.owner.save()
        self.client.login(username='owner', password='pw12345678')
        response = self.client.get(reverse('profiles:detail', kwargs={'username': 'owner'}))
        self.assertEqual(response.status_code, 200)


class ProfileCustomizationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='custom', email='c@example.com', password='pw12345678')
        self.client.login(username='custom', password='pw12345678')

    def test_custom_css_with_script_tag_is_rejected(self):
        response = self.client.post(reverse('profiles:edit_customization'), {
            'theme': 'hot-pink', 'font_choice': 'arial',
            'background_color': '#ffffff', 'accent_color': '#000000',
            'custom_css': 'body { background: url("javascript:alert(1)"); }',
            'media_embed_url': '',
        })
        self.assertContains(response, 'disallowed')

    def test_disallowed_embed_domain_rejected(self):
        response = self.client.post(reverse('profiles:edit_customization'), {
            'theme': 'hot-pink', 'font_choice': 'arial',
            'background_color': '#ffffff', 'accent_color': '#000000',
            'custom_css': '',
            'media_embed_url': 'https://evil.example.com/track.mp3',
        })
        self.assertContains(response, 'limited to')

    def test_valid_customization_saves(self):
        response = self.client.post(reverse('profiles:edit_customization'), {
            'theme': 'hot-pink', 'font_choice': 'comic-sans',
            'background_color': '#ffccee', 'accent_color': '#ff3399',
            'custom_css': 'padding: 4px;',
            'media_embed_url': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        }, follow=True)
        self.user.profile.refresh_from_db()
        self.assertEqual(self.user.profile.theme, 'hot-pink')
