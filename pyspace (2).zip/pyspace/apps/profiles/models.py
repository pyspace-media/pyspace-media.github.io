from django.conf import settings
from django.db import models
from django.urls import reverse

from pyspace_project import settings as project_settings


def profile_picture_path(instance, filename):
    return f'profile_pictures/{instance.user_id}/{filename}'


class Profile(models.Model):
    """
    One-to-one extension of the User model holding all the
    "about me" and customization data that makes a PySpace page feel
    personal - bio, interests, favorites, and layout/theme choices.
    """

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile',
    )

    display_name = models.CharField(max_length=50, blank=True)
    profile_picture = models.ImageField(upload_to=profile_picture_path, blank=True, null=True)
    bio = models.TextField(max_length=2000, blank=True, help_text="Tell people about yourself.")
    status_message = models.CharField(max_length=140, blank=True)
    location = models.CharField(max_length=100, blank=True)

    interests = models.TextField(max_length=500, blank=True, help_text="Comma-separated interests.")
    favorite_music = models.TextField(max_length=500, blank=True)
    favorite_movies = models.TextField(max_length=500, blank=True)
    favorite_books = models.TextField(max_length=500, blank=True)

    personal_links = models.TextField(
        blank=True,
        help_text="One link per line. Shown on your profile as a link list.",
    )

    # --- Customization -------------------------------------------------
    theme = models.CharField(
        max_length=30, choices=[(t, t.replace('-', ' ').title()) for t in project_settings.PYSPACE_ALLOWED_THEMES],
        default='classic-blue',
    )
    font_choice = models.CharField(
        max_length=30, choices=project_settings.PYSPACE_ALLOWED_FONTS, default='arial',
    )
    background_color = models.CharField(max_length=7, default='#ffffff', help_text="Hex color, e.g. #ff00ff")
    accent_color = models.CharField(max_length=7, default='#3366cc')
    background_image = models.ImageField(upload_to='profile_backgrounds/', blank=True, null=True)
    custom_css = models.TextField(
        blank=True, max_length=5000,
        help_text="Advanced: custom CSS, sanitized and scoped to your profile only.",
    )
    media_embed_url = models.URLField(blank=True, help_text="A safe, allow-listed music/media embed URL.")

    view_count = models.PositiveIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s profile"

    def get_absolute_url(self):
        return reverse('profiles:detail', kwargs={'username': self.user.username})

    @property
    def display_name_or_username(self):
        return self.display_name or self.user.username

    @property
    def interest_list(self):
        return [i.strip() for i in self.interests.split(',') if i.strip()]

    @property
    def link_list(self):
        return [l.strip() for l in self.personal_links.splitlines() if l.strip()]
