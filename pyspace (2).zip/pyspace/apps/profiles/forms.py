import re

from django import forms
from django.core.exceptions import ValidationError

from .models import Profile

# Very restrictive custom CSS sanitizer: no <script>, no @import, no
# `expression()`, no `url(javascript:...)`, no HTML tags at all. This is
# a defense-in-depth measure - CSS is still rendered inside a scoped
# <style> block server-side, never as inline event handlers or HTML.
CSS_BLOCKLIST_PATTERNS = [
    r'<\s*script', r'@import', r'expression\s*\(', r'javascript:',
    r'behavior\s*:', r'-moz-binding', r'<\s*/?\s*style',
]


def sanitize_custom_css(css_text: str) -> str:
    lowered = css_text.lower()
    for pattern in CSS_BLOCKLIST_PATTERNS:
        if re.search(pattern, lowered):
            raise ValidationError("Your custom CSS contains disallowed content.")
    return css_text


class ProfileInfoForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = [
            'display_name', 'profile_picture', 'bio', 'status_message',
            'location', 'interests', 'favorite_music', 'favorite_movies',
            'favorite_books', 'personal_links',
        ]
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 5}),
            'personal_links': forms.Textarea(attrs={'rows': 3, 'placeholder': 'https://example.com'}),
        }


class ProfileCustomizationForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = [
            'theme', 'font_choice', 'background_color', 'accent_color',
            'background_image', 'custom_css', 'media_embed_url',
        ]
        widgets = {
            'background_color': forms.TextInput(attrs={'type': 'color'}),
            'accent_color': forms.TextInput(attrs={'type': 'color'}),
            'custom_css': forms.Textarea(attrs={'rows': 8, 'class': 'code-input'}),
        }

    def clean_custom_css(self):
        css = self.cleaned_data.get('custom_css', '')
        if css:
            sanitize_custom_css(css)
        return css

    def clean_media_embed_url(self):
        url = self.cleaned_data.get('media_embed_url', '')
        if url:
            allowed_domains = ('youtube.com', 'youtu.be', 'soundcloud.com', 'bandcamp.com', 'spotify.com')
            if not any(domain in url for domain in allowed_domains):
                raise ValidationError(
                    "Media embeds are limited to YouTube, SoundCloud, Bandcamp, or Spotify links."
                )
        return url
