from django.conf import settings
from django.db import models


class Conversation(models.Model):
    """
    A conversation between exactly two users. We keep this simple
    (no group chats) to match the classic private-messaging inbox
    experience. `participants` is unordered; a helper on the manager
    finds-or-creates the conversation for a given pair.
    """

    participants = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='conversations')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"Conversation #{self.pk}"

    def other_participant(self, user):
        return self.participants.exclude(pk=user.pk).first()

    def unread_count_for(self, user):
        return self.messages.filter(is_read=False).exclude(sender=user).count()

    @classmethod
    def get_or_create_for(cls, user_a, user_b):
        existing = (
            cls.objects.filter(participants=user_a)
            .filter(participants=user_b)
            .distinct()
        )
        for convo in existing:
            if convo.participants.count() == 2:
                return convo, False
        convo = cls.objects.create()
        convo.participants.add(user_a, user_b)
        return convo, True


class Message(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages',
    )
    body = models.TextField(max_length=5000)
    is_read = models.BooleanField(default=False)

    # Per-user soft-delete: each participant can delete their own copy
    # without affecting what the other person sees.
    deleted_by = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name='deleted_messages', blank=True,
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"Message from {self.sender} in conversation {self.conversation_id}"

    def visible_to(self, user):
        return not self.deleted_by.filter(pk=user.pk).exists()
