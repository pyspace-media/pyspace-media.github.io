from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from apps.moderation.models import Block
from apps.notifications.services import notify

from .forms import MessageForm
from .models import Conversation, Message

User = get_user_model()


@login_required
def inbox(request):
    conversations = (
        request.user.conversations
        .prefetch_related('participants', 'messages')
        .all()
    )
    convo_data = []
    for convo in conversations:
        other = convo.other_participant(request.user)
        if other is None:
            continue
        last_message = convo.messages.last()
        convo_data.append({
            'conversation': convo,
            'other': other,
            'last_message': last_message,
            'unread_count': convo.unread_count_for(request.user),
        })
    convo_data.sort(key=lambda d: d['conversation'].updated_at, reverse=True)
    return render(request, 'messaging/inbox.html', {'conversations': convo_data})


@login_required
def thread(request, conversation_id):
    convo = get_object_or_404(request.user.conversations, pk=conversation_id)
    other = convo.other_participant(request.user)

    if request.method == 'POST':
        if other and Block.objects.filter(blocker=other, blocked=request.user).exists():
            messages.error(request, "You can't send messages to this user.")
            return redirect('messaging:thread', conversation_id=convo.id)
        form = MessageForm(request.POST)
        if form.is_valid():
            msg = form.save(commit=False)
            msg.conversation = convo
            msg.sender = request.user
            msg.save()
            convo.save(update_fields=[])  # bump updated_at via auto_now
            if other:
                notify(other, actor=request.user, verb='message', target=msg)
            return redirect('messaging:thread', conversation_id=convo.id)
    else:
        form = MessageForm()

    thread_messages = convo.messages.select_related('sender').exclude(deleted_by=request.user)
    thread_messages.exclude(sender=request.user).filter(is_read=False).update(is_read=True)

    return render(request, 'messaging/thread.html', {
        'conversation': convo, 'other': other, 'thread_messages': thread_messages, 'form': form,
    })


@login_required
def start_conversation(request, username):
    other = get_object_or_404(User, username__iexact=username)
    if other == request.user:
        messages.error(request, "You can't message yourself.")
        return redirect('profiles:detail', username=username)
    if Block.objects.filter(blocker=other, blocked=request.user).exists():
        messages.error(request, "You can't message this user.")
        return redirect('profiles:detail', username=username)
    convo, _ = Conversation.get_or_create_for(request.user, other)
    return redirect('messaging:thread', conversation_id=convo.id)


@login_required
@require_POST
def delete_message(request, message_id):
    msg = get_object_or_404(Message, pk=message_id, conversation__participants=request.user)
    msg.deleted_by.add(request.user)
    return redirect('messaging:thread', conversation_id=msg.conversation_id)
