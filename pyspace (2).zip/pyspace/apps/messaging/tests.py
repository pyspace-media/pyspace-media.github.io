from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User
from apps.moderation.models import Block

from .models import Conversation, Message


class MessagingTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')

    def test_start_conversation_creates_one_conversation(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.get(reverse('messaging:start', kwargs={'username': 'bob'}))
        self.client.get(reverse('messaging:start', kwargs={'username': 'bob'}))
        self.assertEqual(Conversation.objects.filter(participants=self.alice).filter(participants=self.bob).count(), 1)

    def test_send_message(self):
        convo, _ = Conversation.get_or_create_for(self.alice, self.bob)
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('messaging:thread', kwargs={'conversation_id': convo.id}), {'body': 'hi bob'})
        self.assertTrue(Message.objects.filter(conversation=convo, sender=self.alice, body='hi bob').exists())

    def test_blocked_user_cannot_message(self):
        Block.objects.create(blocker=self.bob, blocked=self.alice)
        self.client.login(username='alice', password='pw12345678')
        response = self.client.get(reverse('messaging:start', kwargs={'username': 'bob'}), follow=True)
        self.assertEqual(Conversation.objects.filter(participants=self.alice).filter(participants=self.bob).count(), 0)

    def test_delete_message_is_per_user(self):
        convo, _ = Conversation.get_or_create_for(self.alice, self.bob)
        msg = Message.objects.create(conversation=convo, sender=self.alice, body='delete me')
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('messaging:delete_message', kwargs={'message_id': msg.id}))
        msg.refresh_from_db()
        self.assertFalse(msg.visible_to(self.alice))
        self.assertTrue(msg.visible_to(self.bob))
