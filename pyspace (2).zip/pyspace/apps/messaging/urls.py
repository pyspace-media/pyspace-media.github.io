from django.urls import path

from . import views

app_name = 'messaging'

urlpatterns = [
    path('', views.inbox, name='inbox'),
    path('start/<str:username>/', views.start_conversation, name='start'),
    path('<int:conversation_id>/', views.thread, name='thread'),
    path('message/<int:message_id>/delete/', views.delete_message, name='delete_message'),
]
