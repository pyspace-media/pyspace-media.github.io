from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User
from apps.posts.models import Post

from .models import Comment, ProfileComment


class PostCommentTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')
        self.post = Post.objects.create(author=self.bob, content='hello')

    def test_add_comment(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('comments:add', kwargs={'post_id': self.post.id}), {'content': 'nice post'})
        self.assertTrue(Comment.objects.filter(post=self.post, author=self.alice).exists())

    def test_non_author_non_post_owner_cannot_delete(self):
        comment = Comment.objects.create(post=self.post, author=self.bob, content='mine')
        carl = User.objects.create_user(username='carl', email='c@example.com', password='pw12345678')
        self.client.login(username='carl', password='pw12345678')
        response = self.client.post(reverse('comments:delete', kwargs={'comment_id': comment.id}))
        self.assertEqual(response.status_code, 403)

    def test_post_owner_can_delete_others_comment(self):
        comment = Comment.objects.create(post=self.post, author=self.alice, content='spam')
        self.client.login(username='bob', password='pw12345678')
        self.client.post(reverse('comments:delete', kwargs={'comment_id': comment.id}))
        self.assertFalse(Comment.objects.filter(pk=comment.pk).exists())


class ProfileCommentTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')

    def test_add_profile_comment(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('comments:add_profile', kwargs={'username': 'bob'}), {'content': 'nice page'})
        self.assertTrue(ProfileComment.objects.filter(profile_owner=self.bob, author=self.alice).exists())

    def test_profile_owner_can_delete_comment_left_by_others(self):
        comment = ProfileComment.objects.create(profile_owner=self.bob, author=self.alice, content='hi')
        self.client.login(username='bob', password='pw12345678')
        self.client.post(reverse('comments:delete_profile', kwargs={'comment_id': comment.id}))
        self.assertFalse(ProfileComment.objects.filter(pk=comment.pk).exists())
