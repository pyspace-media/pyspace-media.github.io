from django.conf import settings
from django.db import models


class Comment(models.Model):
    """A comment on a Post."""

    post = models.ForeignKey('posts.Post', on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField(max_length=1000)
    is_removed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"Comment by {self.author} on post {self.post_id}"


class ProfileComment(models.Model):
    """A comment left directly on someone's profile page ("wall post")."""

    profile_owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile_comments_received',
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile_comments_written',
    )
    content = models.TextField(max_length=1000)
    is_removed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Profile comment by {self.author} on {self.profile_owner}'s page"

    def can_delete(self, user):
        return user == self.author or user == self.profile_owner or user.is_staff
