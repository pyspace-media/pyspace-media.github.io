from django.contrib import admin

from .models import Comment, ProfileComment

admin.site.register(Comment)
admin.site.register(ProfileComment)
