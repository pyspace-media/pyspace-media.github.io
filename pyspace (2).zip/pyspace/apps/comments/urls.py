from django.urls import path

from . import views

app_name = 'comments'

urlpatterns = [
    path('post/<int:post_id>/add/', views.add_comment, name='add'),
    path('<int:comment_id>/delete/', views.delete_comment, name='delete'),
    path('profile/<str:username>/add/', views.add_profile_comment, name='add_profile'),
    path('profile/<int:comment_id>/delete/', views.delete_profile_comment, name='delete_profile'),
]
