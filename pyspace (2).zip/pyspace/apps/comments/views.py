from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect
from django.views.decorators.http import require_POST

from apps.notifications.services import notify
from apps.posts.models import Post

from .forms import CommentForm, ProfileCommentForm
from .models import Comment, ProfileComment

User = get_user_model()


@login_required
@require_POST
def add_comment(request, post_id):
    post = get_object_or_404(Post, pk=post_id, is_removed=False)
    form = CommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.post = post
        comment.author = request.user
        comment.save()
        notify(post.author, actor=request.user, verb='comment', target=post)
    else:
        messages.error(request, "Comment couldn't be posted.")
    return redirect('posts:detail', pk=post_id)


@login_required
@require_POST
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, pk=comment_id)
    if comment.author != request.user and comment.post.author != request.user and not request.user.is_staff:
        return HttpResponseForbidden()
    post_id = comment.post_id
    comment.delete()
    return redirect('posts:detail', pk=post_id)


@login_required
@require_POST
def add_profile_comment(request, username):
    owner = get_object_or_404(User, username__iexact=username)
    form = ProfileCommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.profile_owner = owner
        comment.author = request.user
        comment.save()
        notify(owner, actor=request.user, verb='profile_comment', target=comment)
    return redirect('profiles:detail', username=username)


@login_required
@require_POST
def delete_profile_comment(request, comment_id):
    comment = get_object_or_404(ProfileComment, pk=comment_id)
    if not comment.can_delete(request.user):
        return HttpResponseForbidden()
    username = comment.profile_owner.username
    comment.delete()
    return redirect('profiles:detail', username=username)
