from django import forms

from .models import Comment, ProfileComment


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {'content': forms.Textarea(attrs={'rows': 2, 'placeholder': 'Write a comment...'})}


class ProfileCommentForm(forms.ModelForm):
    class Meta:
        model = ProfileComment
        fields = ['content']
        widgets = {'content': forms.Textarea(attrs={'rows': 2, 'placeholder': 'Leave a comment on this profile...'})}
