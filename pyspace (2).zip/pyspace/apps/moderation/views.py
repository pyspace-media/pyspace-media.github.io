from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import ReportForm
from .models import Block, Report

User = get_user_model()

# Only these models can be reported, referenced by ('app_label', 'model')
REPORTABLE_MODELS = {
    'user': ('accounts', 'user'),
    'post': ('posts', 'post'),
    'comment': ('comments', 'comment'),
    'profilecomment': ('comments', 'profilecomment'),
}


@login_required
def file_report(request, kind, object_id):
    if kind not in REPORTABLE_MODELS:
        messages.error(request, "That can't be reported.")
        return redirect('posts:feed')

    app_label, model_name = REPORTABLE_MODELS[kind]
    ct = get_object_or_404(ContentType, app_label=app_label, model=model_name)
    target = get_object_or_404(ct.model_class(), pk=object_id)

    if request.method == 'POST':
        form = ReportForm(request.POST)
        if form.is_valid():
            report = form.save(commit=False)
            report.reporter = request.user
            report.target = target
            report.save()
            messages.success(request, "Thanks - our moderation team will review this.")
            return redirect(request.META.get('HTTP_REFERER', 'posts:feed'))
    else:
        form = ReportForm()

    return render(request, 'moderation/report_form.html', {'form': form, 'target': target, 'kind': kind})


@login_required
@require_POST
def block_user(request, username):
    target = get_object_or_404(User, username__iexact=username)
    if target == request.user:
        messages.error(request, "You can't block yourself.")
        return redirect('profiles:detail', username=username)
    Block.objects.get_or_create(blocker=request.user, blocked=target)

    # Blocking also severs any existing friendship, mirroring how most
    # social platforms treat a block as a hard relationship reset.
    from django.db.models import Q
    from apps.friends.models import Friendship
    Friendship.objects.filter(
        Q(user_from=request.user, user_to=target) | Q(user_from=target, user_to=request.user)
    ).delete()

    messages.info(request, f"You've blocked {target.username}.")
    return redirect('profiles:detail', username=username)


@login_required
@require_POST
def unblock_user(request, username):
    target = get_object_or_404(User, username__iexact=username)
    Block.objects.filter(blocker=request.user, blocked=target).delete()
    messages.info(request, f"You've unblocked {target.username}.")
    return redirect('moderation:blocked_users')


@login_required
def blocked_users(request):
    blocks = Block.objects.filter(blocker=request.user).select_related('blocked')
    return render(request, 'moderation/blocked_users.html', {'blocks': blocks})


@staff_member_required
def report_queue(request):
    reports = Report.objects.filter(status__in=['open', 'reviewing']).select_related('reporter')
    return render(request, 'moderation/queue.html', {'reports': reports})


@staff_member_required
@require_POST
def resolve_report(request, report_id, action):
    report = get_object_or_404(Report, pk=report_id)
    if action == 'dismiss':
        report.status = Report.Status.DISMISSED
    elif action == 'action':
        report.status = Report.Status.ACTIONED
        # Remove the offending content where it makes sense to.
        target = report.target
        if hasattr(target, 'is_removed'):
            target.is_removed = True
            target.save(update_fields=['is_removed'])
    report.resolved_by = request.user
    report.resolved_at = timezone.now()
    report.save(update_fields=['status', 'resolved_by', 'resolved_at'])
    messages.success(request, "Report resolved.")
    return redirect('moderation:queue')
