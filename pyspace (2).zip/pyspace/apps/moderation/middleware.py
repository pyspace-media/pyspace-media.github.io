import time

from django.conf import settings
from django.core.cache import cache
from django.http import HttpResponse

# Paths (by URL name prefix) and their per-minute limits. We check these
# by resolving the path in a lightweight way: matching on path prefixes
# is enough for this project and avoids needing full URL resolution on
# every request.
RATE_LIMITED_PATH_PREFIXES = {
    '/post/': None,  # handled per-post view (like/comment), fall through to default
}


class RateLimitMiddleware:
    """
    Minimal per-user (or per-IP, if anonymous) rate limiter for
    write-heavy endpoints (posting, commenting). Uses Django's cache
    framework so it works with the default local-memory cache in dev
    and a real cache (e.g. Redis/Memcached) in production.

    This is intentionally simple - good enough to blunt basic spam
    bots and accidental double-submits, not a substitute for a proper
    WAF or a queue-based system at real scale.
    """

    #: (method, path suffix) -> (setting name, default limit, window seconds)
    LIMITED_ACTIONS = [
        ('POST', '/like/', 'PYSPACE_RATE_LIMIT_POSTS_PER_MINUTE', 60),
        ('POST', '/comments/', 'PYSPACE_RATE_LIMIT_COMMENTS_PER_MINUTE', 60),
    ]

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == 'POST':
            limit_info = self._match_limit(request.path)
            if limit_info:
                setting_name, window_seconds = limit_info
                limit = getattr(settings, setting_name, 30)
                if self._is_rate_limited(request, setting_name, limit, window_seconds):
                    return HttpResponse(
                        "You're doing that too fast. Please wait a moment and try again.",
                        status=429,
                    )
        return self.get_response(request)

    def _match_limit(self, path):
        for method, suffix, setting_name, window in self.LIMITED_ACTIONS:
            if suffix in path:
                return setting_name, window
        return None

    def _is_rate_limited(self, request, key_prefix, limit, window_seconds):
        identity = (
            f"user:{request.user.id}" if getattr(request.user, 'is_authenticated', False)
            else f"ip:{self._client_ip(request)}"
        )
        cache_key = f"ratelimit:{key_prefix}:{identity}"
        now = time.time()

        history = cache.get(cache_key, [])
        # Drop timestamps outside the window
        history = [t for t in history if now - t < window_seconds]

        if len(history) >= limit:
            return True

        history.append(now)
        cache.set(cache_key, history, timeout=window_seconds)
        return False

    @staticmethod
    def _client_ip(request):
        forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
        if forwarded:
            return forwarded.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR', 'unknown')
