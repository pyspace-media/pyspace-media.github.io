from django.urls import path

from . import views

app_name = 'moderation'

urlpatterns = [
    path('report/<str:kind>/<int:object_id>/', views.file_report, name='report'),
    path('block/<str:username>/', views.block_user, name='block'),
    path('unblock/<str:username>/', views.unblock_user, name='unblock'),
    path('blocked/', views.blocked_users, name='blocked_users'),
    path('queue/', views.report_queue, name='queue'),
    path('queue/<int:report_id>/<str:action>/', views.resolve_report, name='resolve'),
]
