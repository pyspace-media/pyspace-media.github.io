from django.contrib.contenttypes.models import ContentType
from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User
from apps.friends.models import Friendship
from apps.posts.models import Post

from .models import Block, Report


class ReportTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')
        self.staff = User.objects.create_user(
            username='staffer', email='s@example.com', password='pw12345678', is_staff=True,
        )

    def test_file_report_on_post(self):
        post = Post.objects.create(author=self.bob, content='spammy')
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('moderation:report', kwargs={'kind': 'post', 'object_id': post.id}), {
            'reason': 'spam', 'details': 'looks like spam',
        })
        self.assertTrue(Report.objects.filter(reporter=self.alice, reason='spam').exists())

    def test_non_staff_cannot_access_queue(self):
        self.client.login(username='alice', password='pw12345678')
        response = self.client.get(reverse('moderation:queue'))
        self.assertNotEqual(response.status_code, 200)

    def test_staff_can_action_report_and_remove_post(self):
        post = Post.objects.create(author=self.bob, content='bad content')
        ct = ContentType.objects.get_for_model(Post)
        report = Report.objects.create(
            reporter=self.alice, target_content_type=ct, target_object_id=post.id, reason='spam',
        )
        self.client.login(username='staffer', password='pw12345678')
        self.client.post(reverse('moderation:resolve', kwargs={'report_id': report.id, 'action': 'action'}))
        post.refresh_from_db()
        report.refresh_from_db()
        self.assertTrue(post.is_removed)
        self.assertEqual(report.status, 'actioned')


class BlockTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')

    def test_block_removes_existing_friendship(self):
        Friendship.objects.create(user_from=self.alice, user_to=self.bob)
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('moderation:block', kwargs={'username': 'bob'}))
        self.assertFalse(Friendship.objects.are_friends(self.alice, self.bob))
        self.assertTrue(Block.objects.filter(blocker=self.alice, blocked=self.bob).exists())

    def test_unblock(self):
        Block.objects.create(blocker=self.alice, blocked=self.bob)
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('moderation:unblock', kwargs={'username': 'bob'}))
        self.assertFalse(Block.objects.filter(blocker=self.alice, blocked=self.bob).exists())
