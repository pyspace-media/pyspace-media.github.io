from io import BytesIO

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from PIL import Image

from apps.accounts.models import User

from .models import Album, Photo


def make_test_image(name='test.png', size_kb=1):
    buf = BytesIO()
    Image.new('RGB', (10, 10), color='red').save(buf, format='PNG')
    buf.seek(0)
    return SimpleUploadedFile(name, buf.read(), content_type='image/png')


class AlbumTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')

    def test_create_album(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('media_app:create_album'), {'title': 'Trip', 'description': 'fun'})
        self.assertTrue(Album.objects.filter(owner=self.alice, title='Trip').exists())

    def test_only_owner_can_delete_album(self):
        album = Album.objects.create(owner=self.alice, title='Mine')
        self.client.login(username='bob', password='pw12345678')
        response = self.client.post(reverse('media_app:delete_album', kwargs={'album_id': album.id}))
        self.assertEqual(response.status_code, 403)
        self.assertTrue(Album.objects.filter(pk=album.pk).exists())

    def test_upload_photo_to_own_album(self):
        album = Album.objects.create(owner=self.alice, title='Mine')
        self.client.login(username='alice', password='pw12345678')
        image = make_test_image()
        self.client.post(reverse('media_app:album_detail', kwargs={'album_id': album.id}), {
            'image': image, 'caption': 'nice',
        })
        self.assertEqual(Photo.objects.filter(album=album).count(), 1)

    def test_rejects_disallowed_file_extension(self):
        album = Album.objects.create(owner=self.alice, title='Mine')
        bad_file = SimpleUploadedFile('malware.exe', b'not an image', content_type='application/octet-stream')
        photo = Photo(album=album, image=bad_file, caption='bad')
        with self.assertRaises(Exception):
            photo.full_clean()
