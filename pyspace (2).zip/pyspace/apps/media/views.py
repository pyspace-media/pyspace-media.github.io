from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import AlbumForm, PhotoForm
from .models import Album, Photo

User = get_user_model()


def album_list(request, username):
    owner = get_object_or_404(User, username__iexact=username)
    albums = Album.objects.filter(owner=owner).prefetch_related('photos')
    return render(request, 'media/album_list.html', {'owner': owner, 'albums': albums})


def album_detail(request, album_id):
    album = get_object_or_404(Album.objects.select_related('owner'), pk=album_id)
    photos = album.photos.all()

    if request.user == album.owner and request.method == 'POST':
        form = PhotoForm(request.POST, request.FILES)
        if form.is_valid():
            photo = form.save(commit=False)
            photo.album = album
            photo.save()
            messages.success(request, "Photo added.")
            return redirect('media_app:album_detail', album_id=album.id)
    else:
        form = PhotoForm() if request.user == album.owner else None

    return render(request, 'media/album_detail.html', {'album': album, 'photos': photos, 'form': form})


@login_required
def create_album(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            album = form.save(commit=False)
            album.owner = request.user
            album.save()
            messages.success(request, f'Album "{album.title}" created.')
            return redirect('media_app:album_detail', album_id=album.id)
    else:
        form = AlbumForm()
    return render(request, 'media/create_album.html', {'form': form})


@login_required
@require_POST
def delete_album(request, album_id):
    album = get_object_or_404(Album, pk=album_id)
    if album.owner != request.user and not request.user.is_staff:
        return HttpResponseForbidden()
    album.delete()
    messages.info(request, "Album deleted.")
    return redirect('media_app:album_list', username=request.user.username)


@login_required
@require_POST
def delete_photo(request, photo_id):
    photo = get_object_or_404(Photo, pk=photo_id)
    if photo.album.owner != request.user and not request.user.is_staff:
        return HttpResponseForbidden()
    album_id = photo.album_id
    photo.delete()
    return redirect('media_app:album_detail', album_id=album_id)
