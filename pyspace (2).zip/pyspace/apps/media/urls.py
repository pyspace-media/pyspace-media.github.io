from django.urls import path

from . import views

app_name = 'media_app'

urlpatterns = [
    path('create/', views.create_album, name='create_album'),
    path('user/<str:username>/', views.album_list, name='album_list'),
    path('<int:album_id>/', views.album_detail, name='album_detail'),
    path('<int:album_id>/delete/', views.delete_album, name='delete_album'),
    path('photo/<int:photo_id>/delete/', views.delete_photo, name='delete_photo'),
]
