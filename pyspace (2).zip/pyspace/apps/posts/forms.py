from django import forms

from .models import Post


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['content', 'image']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3, 'placeholder': "What's happening?", 'maxlength': 3000}),
        }

    def clean(self):
        cleaned = super().clean()
        if not cleaned.get('content', '').strip() and not cleaned.get('image'):
            raise forms.ValidationError("Write something or attach an image before posting.")
        return cleaned
