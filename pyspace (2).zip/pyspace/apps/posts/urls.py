from django.urls import path

from . import views

app_name = 'posts'

urlpatterns = [
    path('', views.feed, name='feed'),
    path('post/<int:pk>/', views.post_detail, name='detail'),
    path('post/<int:pk>/delete/', views.delete_post, name='delete'),
    path('post/<int:pk>/like/', views.toggle_like, name='toggle_like'),
]
