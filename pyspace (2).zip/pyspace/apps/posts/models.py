from django.conf import settings
from django.db import models
from django.urls import reverse


def post_image_path(instance, filename):
    return f'post_images/{instance.author_id}/{filename}'


class Post(models.Model):
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='posts',
    )
    content = models.TextField(max_length=3000, blank=True)
    image = models.ImageField(upload_to=post_image_path, blank=True, null=True)

    is_removed = models.BooleanField(default=False, help_text="Hidden by moderation.")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [models.Index(fields=['author', '-created_at'])]

    def __str__(self):
        return f"Post #{self.pk} by {self.author}"

    def get_absolute_url(self):
        return reverse('posts:detail', kwargs={'pk': self.pk})

    @property
    def like_count(self):
        return self.likes.count()

    @property
    def comment_count(self):
        return self.comments.count()


class Like(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='post_likes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['post', 'user'], name='unique_like_per_user')]

    def __str__(self):
        return f"{self.user} likes {self.post_id}"
