from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from apps.friends.models import Friendship
from apps.notifications.services import notify

from .forms import PostForm
from .models import Like, Post


@login_required
def feed(request):
    friend_qs = Friendship.objects.friends_of(request.user)
    friend_ids = list(friend_qs.values_list('id', flat=True)) + [request.user.id]

    posts = (
        Post.objects.filter(author_id__in=friend_ids, is_removed=False)
        .select_related('author', 'author__profile')
        .prefetch_related('likes')
    )
    paginator = Paginator(posts, settings.PYSPACE_POSTS_PER_PAGE)
    page_obj = paginator.get_page(request.GET.get('page'))

    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, "Posted!")
            return redirect('posts:feed')
    else:
        form = PostForm()

    liked_post_ids = set(
        Like.objects.filter(user=request.user, post__in=page_obj.object_list).values_list('post_id', flat=True)
    )

    return render(request, 'posts/feed.html', {
        'form': form,
        'page_obj': page_obj,
        'liked_post_ids': liked_post_ids,
    })


def post_detail(request, pk):
    post = get_object_or_404(Post.objects.select_related('author'), pk=pk, is_removed=False)
    comments = post.comments.select_related('author').order_by('created_at')
    liked = request.user.is_authenticated and post.likes.filter(user=request.user).exists()
    return render(request, 'posts/detail.html', {'post': post, 'comments': comments, 'liked': liked})


@login_required
@require_POST
def delete_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if post.author != request.user and not request.user.is_staff:
        return HttpResponseForbidden("You can't delete this post.")
    post.delete()
    messages.info(request, "Post deleted.")
    return redirect(request.META.get('HTTP_REFERER', 'posts:feed'))


@login_required
@require_POST
def toggle_like(request, pk):
    post = get_object_or_404(Post, pk=pk, is_removed=False)
    like, created = Like.objects.get_or_create(post=post, user=request.user)
    if not created:
        like.delete()
    else:
        notify(post.author, actor=request.user, verb='like', target=post)
    return redirect(request.META.get('HTTP_REFERER', 'posts:feed'))
