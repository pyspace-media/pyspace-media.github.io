from django.contrib import admin

from .models import Like, Post


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'author', 'created_at', 'is_removed')
    list_filter = ('is_removed',)
    search_fields = ('author__username', 'content')
    actions = ['remove_posts', 'restore_posts']

    @admin.action(description="Remove selected posts (moderation)")
    def remove_posts(self, request, queryset):
        queryset.update(is_removed=True)

    @admin.action(description="Restore selected posts")
    def restore_posts(self, request, queryset):
        queryset.update(is_removed=False)


admin.site.register(Like)
