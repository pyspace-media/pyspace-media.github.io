from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User
from apps.friends.models import Friendship

from .models import Like, Post


class FeedTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='a@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='b@example.com', password='pw12345678')
        self.stranger = User.objects.create_user(username='carl', email='c@example.com', password='pw12345678')
        Friendship.objects.create(user_from=self.alice, user_to=self.bob)

    def test_feed_shows_own_and_friends_posts_not_strangers(self):
        Post.objects.create(author=self.alice, content='alice post')
        Post.objects.create(author=self.bob, content='bob post')
        Post.objects.create(author=self.stranger, content='stranger post')

        self.client.login(username='alice', password='pw12345678')
        response = self.client.get(reverse('posts:feed'))
        self.assertContains(response, 'alice post')
        self.assertContains(response, 'bob post')
        self.assertNotContains(response, 'stranger post')

    def test_create_post_requires_content_or_image(self):
        self.client.login(username='alice', password='pw12345678')
        response = self.client.post(reverse('posts:feed'), {'content': ''})
        self.assertEqual(Post.objects.filter(author=self.alice).count(), 0)

    def test_toggle_like(self):
        post = Post.objects.create(author=self.bob, content='likeable')
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('posts:toggle_like', kwargs={'pk': post.pk}))
        self.assertTrue(Like.objects.filter(post=post, user=self.alice).exists())
        self.client.post(reverse('posts:toggle_like', kwargs={'pk': post.pk}))
        self.assertFalse(Like.objects.filter(post=post, user=self.alice).exists())

    def test_only_author_can_delete_post(self):
        post = Post.objects.create(author=self.bob, content='not yours')
        self.client.login(username='alice', password='pw12345678')
        response = self.client.post(reverse('posts:delete', kwargs={'pk': post.pk}))
        self.assertEqual(response.status_code, 403)
        self.assertTrue(Post.objects.filter(pk=post.pk).exists())
