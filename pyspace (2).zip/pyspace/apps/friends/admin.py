from django.contrib import admin

from .models import FriendRequest, Friendship


@admin.register(FriendRequest)
class FriendRequestAdmin(admin.ModelAdmin):
    list_display = ('sender', 'recipient', 'status', 'created_at')
    list_filter = ('status',)
    search_fields = ('sender__username', 'recipient__username')


@admin.register(Friendship)
class FriendshipAdmin(admin.ModelAdmin):
    list_display = ('user_from', 'user_to', 'created_at')
    search_fields = ('user_from__username', 'user_to__username')
