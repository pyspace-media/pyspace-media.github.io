from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.notifications.services import notify

from .models import FriendRequest, Friendship

User = get_user_model()


@login_required
@require_POST
def send_request(request, username):
    recipient = get_object_or_404(User, username__iexact=username)
    if recipient == request.user:
        messages.error(request, "You can't send yourself a friend request.")
        return redirect('profiles:detail', username=username)

    if Friendship.objects.are_friends(request.user, recipient):
        messages.info(request, "You're already friends.")
        return redirect('profiles:detail', username=username)

    try:
        with transaction.atomic():
            fr = FriendRequest.objects.create(sender=request.user, recipient=recipient)
        notify(recipient, actor=request.user, verb='friend_request', target=fr)
        messages.success(request, f"Friend request sent to {recipient.username}.")
    except IntegrityError:
        messages.info(request, "You already have a pending request to this user.")
    return redirect('profiles:detail', username=username)


@login_required
@require_POST
def respond_request(request, request_id, action):
    fr = get_object_or_404(FriendRequest, id=request_id, recipient=request.user, status='pending')

    if action == 'accept':
        fr.status = FriendRequest.Status.ACCEPTED
        fr.responded_at = timezone.now()
        fr.save(update_fields=['status', 'responded_at'])
        Friendship.objects.get_or_create(user_from=fr.sender, user_to=fr.recipient)
        notify(fr.sender, actor=request.user, verb='friend_accept', target=fr)
        messages.success(request, f"You are now friends with {fr.sender.username}.")
    elif action == 'decline':
        fr.status = FriendRequest.Status.DECLINED
        fr.responded_at = timezone.now()
        fr.save(update_fields=['status', 'responded_at'])
        messages.info(request, "Friend request declined.")
    return redirect('friends:requests')


@login_required
@require_POST
def remove_friend(request, username):
    other = get_object_or_404(User, username__iexact=username)
    from django.db.models import Q
    Friendship.objects.filter(
        Q(user_from=request.user, user_to=other) | Q(user_from=other, user_to=request.user)
    ).delete()
    messages.info(request, f"Removed {other.username} from your friends.")
    return redirect('profiles:detail', username=username)


@login_required
def friend_requests(request):
    incoming = FriendRequest.objects.filter(recipient=request.user, status='pending').select_related('sender')
    outgoing = FriendRequest.objects.filter(sender=request.user, status='pending').select_related('recipient')
    return render(request, 'friends/requests.html', {'incoming': incoming, 'outgoing': outgoing})


@login_required
def friends_list(request, username=None):
    target = get_object_or_404(User, username__iexact=username) if username else request.user
    friends = Friendship.objects.friends_of(target)
    return render(request, 'friends/list.html', {'target': target, 'friends': friends})
