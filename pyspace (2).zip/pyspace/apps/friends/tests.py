from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import FriendRequest, Friendship


class FriendRequestFlowTests(TestCase):
    def setUp(self):
        self.alice = User.objects.create_user(username='alice', email='alice@example.com', password='pw12345678')
        self.bob = User.objects.create_user(username='bob', email='bob@example.com', password='pw12345678')

    def test_send_request_creates_pending_request(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('friends:send_request', kwargs={'username': 'bob'}))
        self.assertTrue(
            FriendRequest.objects.filter(sender=self.alice, recipient=self.bob, status='pending').exists()
        )

    def test_cannot_send_duplicate_pending_request(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('friends:send_request', kwargs={'username': 'bob'}))
        self.client.post(reverse('friends:send_request', kwargs={'username': 'bob'}))
        self.assertEqual(
            FriendRequest.objects.filter(sender=self.alice, recipient=self.bob, status='pending').count(), 1
        )

    def test_cannot_send_request_to_self(self):
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('friends:send_request', kwargs={'username': 'alice'}))
        self.assertFalse(FriendRequest.objects.filter(sender=self.alice, recipient=self.alice).exists())

    def test_accept_request_creates_friendship(self):
        fr = FriendRequest.objects.create(sender=self.alice, recipient=self.bob)
        self.client.login(username='bob', password='pw12345678')
        self.client.post(reverse('friends:respond_request', kwargs={'request_id': fr.id, 'action': 'accept'}))
        self.assertTrue(Friendship.objects.are_friends(self.alice, self.bob))

    def test_decline_request_does_not_create_friendship(self):
        fr = FriendRequest.objects.create(sender=self.alice, recipient=self.bob)
        self.client.login(username='bob', password='pw12345678')
        self.client.post(reverse('friends:respond_request', kwargs={'request_id': fr.id, 'action': 'decline'}))
        self.assertFalse(Friendship.objects.are_friends(self.alice, self.bob))

    def test_remove_friend(self):
        Friendship.objects.create(user_from=self.alice, user_to=self.bob)
        self.client.login(username='alice', password='pw12345678')
        self.client.post(reverse('friends:remove', kwargs={'username': 'bob'}))
        self.assertFalse(Friendship.objects.are_friends(self.alice, self.bob))
