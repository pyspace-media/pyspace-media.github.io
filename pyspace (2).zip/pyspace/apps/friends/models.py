from django.conf import settings
from django.db import models
from django.db.models import Q


class FriendRequest(models.Model):
    class Status(models.TextChoices):
        PENDING = 'pending', 'Pending'
        ACCEPTED = 'accepted', 'Accepted'
        DECLINED = 'declined', 'Declined'
        CANCELED = 'canceled', 'Canceled'

    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_friend_requests',
    )
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_friend_requests',
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['sender', 'recipient'],
                condition=Q(status='pending'),
                name='unique_pending_request',
            )
        ]

    def __str__(self):
        return f"{self.sender} -> {self.recipient} ({self.status})"


class FriendshipManager(models.Manager):
    def are_friends(self, user_a, user_b):
        if not user_a.is_authenticated:
            return False
        return self.filter(
            Q(user_from=user_a, user_to=user_b) | Q(user_from=user_b, user_to=user_a)
        ).exists()

    def friends_of(self, user):
        """Returns a queryset of User objects who are friends with `user`."""
        from django.contrib.auth import get_user_model
        User = get_user_model()
        friend_ids = set(
            self.filter(user_from=user).values_list('user_to_id', flat=True)
        ) | set(
            self.filter(user_to=user).values_list('user_from_id', flat=True)
        )
        return User.objects.filter(id__in=friend_ids)

    def mutual_friends(self, user_a, user_b):
        return self.friends_of(user_a) & self.friends_of(user_b)


class Friendship(models.Model):
    """
    A symmetric friendship edge, created once a FriendRequest is accepted.
    We store one row per pair (user_from is simply whoever accepted last,
    it carries no directional meaning after creation).
    """

    user_from = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='friendships_initiated',
    )
    user_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='friendships_received',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    objects = FriendshipManager()

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['user_from', 'user_to'], name='unique_friendship_pair'),
        ]

    def __str__(self):
        return f"{self.user_from} <-> {self.user_to}"
