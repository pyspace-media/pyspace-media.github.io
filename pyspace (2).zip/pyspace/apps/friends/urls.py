from django.urls import path

from . import views

app_name = 'friends'

urlpatterns = [
    path('requests/', views.friend_requests, name='requests'),
    path('request/<str:username>/send/', views.send_request, name='send_request'),
    path('request/<int:request_id>/<str:action>/', views.respond_request, name='respond_request'),
    path('<str:username>/remove/', views.remove_friend, name='remove'),
    path('<str:username>/list/', views.friends_list, name='list_for_user'),
    path('list/', views.friends_list, name='list'),
]
