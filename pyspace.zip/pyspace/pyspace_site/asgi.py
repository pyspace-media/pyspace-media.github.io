"""ASGI config for the PySpace project."""
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pyspace_site.settings')

application = get_asgi_application()
