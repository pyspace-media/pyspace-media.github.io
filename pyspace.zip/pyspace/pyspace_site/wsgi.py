"""WSGI config for the PySpace project."""
import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pyspace_site.settings')

application = get_wsgi_application()
