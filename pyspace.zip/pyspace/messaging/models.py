from django.conf import settings
from django.db import models
from django.db.models import Q


class MessageManager(models.Manager):

    def between(self, user_a, user_b):
        return self.filter(
            Q(sender=user_a, recipient=user_b) | Q(sender=user_b, recipient=user_a)
        ).order_by('created_at')

    def conversations_for(self, user):
        """
        Return a list of dicts: {'other_user': User, 'last_message': Message,
        'unread_count': int} - one per person `user` has exchanged messages with,
        most recent conversation first.
        """
        my_messages = self.filter(Q(sender=user) | Q(recipient=user)).select_related(
            'sender', 'recipient'
        )
        conversations = {}
        for msg in my_messages:
            other = msg.recipient if msg.sender_id == user.id else msg.sender
            entry = conversations.get(other.id)
            if entry is None or msg.created_at > entry['last_message'].created_at:
                conversations[other.id] = {'other_user': other, 'last_message': msg}

        for entry in conversations.values():
            entry['unread_count'] = self.filter(
                sender=entry['other_user'], recipient=user, is_read=False
            ).count()

        return sorted(
            conversations.values(), key=lambda e: e['last_message'].created_at, reverse=True
        )


class Message(models.Model):
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages'
    )
    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_messages'
    )
    content = models.TextField(max_length=3000)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = MessageManager()

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"{self.sender.username} -> {self.recipient.username}: {self.content[:30]}"
