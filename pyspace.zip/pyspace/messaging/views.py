from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from messaging.forms import MessageForm
from messaging.models import Message
from notifications.utils import notify


@login_required
def inbox(request):
    conversations = Message.objects.conversations_for(request.user)
    return render(request, 'messaging/inbox.html', {'conversations': conversations})


@login_required
def thread(request, username):
    other_user = get_object_or_404(User, username=username)

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.recipient = other_user
            message.save()
            notify(
                recipient=other_user,
                actor=request.user,
                verb='sent you a message',
                target_url=reverse('messaging:thread', kwargs={'username': request.user.username}),
            )
            return redirect('messaging:thread', username=username)
    else:
        form = MessageForm()

    messages_qs = Message.objects.between(request.user, other_user)
    messages_qs.filter(sender=other_user, recipient=request.user, is_read=False).update(is_read=True)

    return render(request, 'messaging/thread.html', {
        'other_user': other_user,
        'thread_messages': messages_qs,
        'form': form,
    })
