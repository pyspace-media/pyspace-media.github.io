from django.urls import path

from messaging import views

app_name = 'messaging'

urlpatterns = [
    path('', views.inbox, name='inbox'),
    path('with/<str:username>/', views.thread, name='thread'),
]
