"""
Preset "starter" themes for PySpace profiles.

These are just convenient bundles of colors/fonts that a user can apply
with one click. Under the hood everything is stored as plain fields on
the Profile model, so users can still fine-tune every value afterwards.
"""

THEME_PRESETS = {
    'classic_blue': {
        'label': 'Classic Blue',
        'bg_color': '#6699CC',
        'panel_color': '#FFFFFF',
        'text_color': '#000000',
        'header_color': '#003366',
        'accent_color': '#FF9900',
        'font_choice': 'arial',
    },
    'retro_web': {
        'label': 'Retro Web 1.0',
        'bg_color': '#C0C0C0',
        'panel_color': '#FFFFFF',
        'text_color': '#000000',
        'header_color': '#000080',
        'accent_color': '#FF00FF',
        'font_choice': 'comic-sans',
    },
    'hot_pink': {
        'label': 'Hot Pink Punk',
        'bg_color': '#FF1493',
        'panel_color': '#FFF0F5',
        'text_color': '#4B0082',
        'header_color': '#8B008B',
        'accent_color': '#00FFFF',
        'font_choice': 'comic-sans',
    },
    'matrix_green': {
        'label': 'Matrix Green',
        'bg_color': '#000000',
        'panel_color': '#0D0D0D',
        'text_color': '#00FF41',
        'header_color': '#00FF41',
        'accent_color': '#00CC33',
        'font_choice': 'courier',
    },
    'sunset': {
        'label': 'Sunset Gradient',
        'bg_color': '#FF6B35',
        'panel_color': '#FFF3E0',
        'text_color': '#3D0000',
        'header_color': '#D7263D',
        'accent_color': '#F4D35E',
        'font_choice': 'georgia',
    },
    'pastel_dream': {
        'label': 'Pastel Dream',
        'bg_color': '#E0BBE4',
        'panel_color': '#FFFDF7',
        'text_color': '#5A4A6B',
        'header_color': '#957DAD',
        'accent_color': '#D291BC',
        'font_choice': 'comic-sans',
    },
    'midnight': {
        'label': 'Midnight',
        'bg_color': '#0F0F23',
        'panel_color': '#1B1B3A',
        'text_color': '#E0E0FF',
        'header_color': '#8A2BE2',
        'accent_color': '#FF6EC7',
        'font_choice': 'verdana',
    },
}

FONT_CHOICES = [
    ('arial', 'Arial'),
    ('verdana', 'Verdana'),
    ('georgia', 'Georgia'),
    ('courier', 'Courier New'),
    ('comic-sans', 'Comic Sans MS'),
    ('times', 'Times New Roman'),
]
