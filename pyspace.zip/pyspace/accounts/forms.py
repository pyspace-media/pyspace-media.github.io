from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from accounts.models import Profile
from accounts.themes import THEME_PRESETS


class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class ProfileInfoForm(forms.ModelForm):
    """Editing bio-type info and the profile picture."""

    class Meta:
        model = Profile
        fields = ['display_name', 'status', 'location', 'bio', 'profile_picture']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 6, 'maxlength': 2000}),
            'status': forms.TextInput(attrs={'placeholder': "What's on your mind?"}),
        }


class ColorInput(forms.TextInput):
    input_type = 'color'


class ProfileThemeForm(forms.ModelForm):
    """The fun part: colors, fonts, and custom CSS."""

    preset = forms.ChoiceField(
        required=False,
        choices=[('', '-- Choose a starter theme (optional) --')] +
                [(key, val['label']) for key, val in THEME_PRESETS.items()],
        help_text="Picking a preset fills in the colors below. You can still tweak them."
    )

    field_order = [
        'preset', 'bg_color', 'panel_color', 'text_color',
        'header_color', 'accent_color', 'font_choice', 'custom_css',
    ]

    class Meta:
        model = Profile
        fields = [
            'bg_color', 'panel_color', 'text_color',
            'header_color', 'accent_color', 'font_choice', 'custom_css',
        ]
        widgets = {
            'bg_color': ColorInput(),
            'panel_color': ColorInput(),
            'text_color': ColorInput(),
            'header_color': ColorInput(),
            'accent_color': ColorInput(),
            'custom_css': forms.Textarea(attrs={
                'rows': 8,
                'placeholder': '/* Advanced: add your own CSS rules here */',
            }),
        }

    # Note: applying a preset happens live in the browser via JavaScript
    # (see profile_edit_theme.html), which fills in the color/font fields
    # below before the form is submitted. The `preset` field itself isn't
    # saved anywhere - it's just a convenient shortcut for the user.
