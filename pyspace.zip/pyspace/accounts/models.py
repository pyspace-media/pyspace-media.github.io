from django.conf import settings
from django.db import models
from django.urls import reverse

from accounts.themes import FONT_CHOICES


class Profile(models.Model):
    """
    Extra, customizable info attached to every User.

    This is where all the "make it your own" MySpace-style profile
    customization lives: colors, fonts, bio, picture, etc.
    """

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile'
    )

    display_name = models.CharField(max_length=50, blank=True)
    bio = models.TextField(max_length=2000, blank=True, help_text="Tell people about yourself.")
    status = models.CharField(
        max_length=100, blank=True,
        help_text="A short status/mood, e.g. 'feeling great!'"
    )
    location = models.CharField(max_length=100, blank=True)
    profile_picture = models.ImageField(
        upload_to='profile_pics/', blank=True, null=True
    )

    # --- Profile customization ---
    bg_color = models.CharField(max_length=7, default='#6699CC')
    panel_color = models.CharField(max_length=7, default='#FFFFFF')
    text_color = models.CharField(max_length=7, default='#000000')
    header_color = models.CharField(max_length=7, default='#003366')
    accent_color = models.CharField(max_length=7, default='#FF9900')
    font_choice = models.CharField(max_length=20, choices=FONT_CHOICES, default='arial')
    custom_css = models.TextField(
        blank=True,
        help_text="Optional: add your own CSS to really make this page yours."
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}'s profile"

    def get_absolute_url(self):
        return reverse('accounts:profile', kwargs={'username': self.user.username})

    @property
    def display(self):
        """The name to show for this user: display_name if set, else username."""
        return self.display_name or self.user.username

    def font_family_css(self):
        mapping = {
            'arial': "Arial, Helvetica, sans-serif",
            'verdana': "Verdana, Geneva, sans-serif",
            'georgia': "Georgia, 'Times New Roman', serif",
            'courier': "'Courier New', Courier, monospace",
            'comic-sans': "'Comic Sans MS', 'Comic Sans', cursive",
            'times': "'Times New Roman', Times, serif",
        }
        return mapping.get(self.font_choice, mapping['arial'])
