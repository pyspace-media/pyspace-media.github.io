from django.contrib.auth import views as auth_views
from django.urls import path

from accounts import views

app_name = 'accounts'

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('search/', views.search_users, name='search'),

    path('profile/edit/', views.profile_edit_info, name='profile_edit_info'),
    path('profile/edit/theme/', views.profile_edit_theme, name='profile_edit_theme'),
    path('profile/<str:username>/', views.profile_detail, name='profile'),
]
