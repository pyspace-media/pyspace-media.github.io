from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from accounts.forms import ProfileInfoForm, ProfileThemeForm, SignUpForm
from accounts.themes import THEME_PRESETS
from friends.models import FriendRequest


def signup(request):
    if request.user.is_authenticated:
        return redirect('posts:feed')

    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Welcome to PySpace, {user.username}! Make this page yours.")
            return redirect('accounts:profile', username=user.username)
    else:
        form = SignUpForm()

    return render(request, 'accounts/signup.html', {'form': form})


def profile_detail(request, username):
    profile_user = get_object_or_404(User, username=username)
    profile = profile_user.profile

    # Local imports to avoid circular app dependencies at import time.
    from friends.services import are_friends, friendship_status
    from photos.models import Album
    from posts.models import Post, ProfileComment
    from posts.forms import ProfileCommentForm

    posts = Post.objects.filter(author=profile_user).order_by('-created_at')[:15]
    profile_comments = profile_user.received_profile_comments.select_related('author')[:20]
    albums = Album.objects.filter(owner=profile_user).order_by('-created_at')[:6]

    friend_status = None
    if request.user.is_authenticated and request.user != profile_user:
        friend_status = friendship_status(request.user, profile_user)

    friends_count = FriendRequest.objects.accepted_for_user(profile_user).count()
    friend_preview = FriendRequest.objects.friends_of(profile_user)[:9]

    context = {
        'profile_user': profile_user,
        'profile': profile,
        'posts': posts,
        'profile_comments': profile_comments,
        'profile_comment_form': ProfileCommentForm(),
        'albums': albums,
        'friend_status': friend_status,
        'friends_count': friends_count,
        'friend_preview': friend_preview,
        'is_own_profile': request.user.is_authenticated and request.user == profile_user,
    }
    return render(request, 'accounts/profile_detail.html', context)


@login_required
def profile_edit_info(request):
    profile = request.user.profile
    if request.method == 'POST':
        form = ProfileInfoForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Your profile info has been updated.")
            return redirect('accounts:profile', username=request.user.username)
    else:
        form = ProfileInfoForm(instance=profile)
    return render(request, 'accounts/profile_edit_info.html', {'form': form})


@login_required
def profile_edit_theme(request):
    profile = request.user.profile
    if request.method == 'POST':
        form = ProfileThemeForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Your new look has been saved!")
            return redirect('accounts:profile', username=request.user.username)
    else:
        form = ProfileThemeForm(instance=profile)
    return render(request, 'accounts/profile_edit_theme.html', {
        'form': form,
        'presets_json': _presets_as_json(),
    })


def _presets_as_json():
    import json
    return json.dumps(THEME_PRESETS)


@login_required
def search_users(request):
    query = request.GET.get('q', '').strip()
    results = []
    if query:
        results = User.objects.filter(
            Q(username__icontains=query) |
            Q(profile__display_name__icontains=query) |
            Q(profile__location__icontains=query)
        ).exclude(id=request.user.id).select_related('profile')[:30]
    return render(request, 'accounts/search_results.html', {
        'query': query,
        'results': results,
    })
