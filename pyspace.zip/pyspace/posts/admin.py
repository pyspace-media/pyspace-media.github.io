from django.contrib import admin

from posts.models import Comment, Like, Post, ProfileComment

admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Like)
admin.site.register(ProfileComment)
