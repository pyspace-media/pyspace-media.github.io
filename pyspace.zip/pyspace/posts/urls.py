from django.urls import path

from posts import views

app_name = 'posts'

urlpatterns = [
    path('', views.feed, name='feed'),
    path('post/<int:pk>/like/', views.like_post, name='like'),
    path('post/<int:pk>/comment/', views.add_comment, name='comment'),
    path('post/<int:pk>/delete/', views.delete_post, name='delete'),
    path('profile-comment/<str:username>/add/', views.add_profile_comment, name='add_profile_comment'),
    path('profile-comment/<int:pk>/delete/', views.delete_profile_comment, name='delete_profile_comment'),
]
