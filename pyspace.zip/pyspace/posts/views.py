from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from friends.models import FriendRequest
from notifications.utils import notify
from posts.forms import CommentForm, PostForm, ProfileCommentForm
from posts.models import Comment, Like, Post, ProfileComment


@login_required
def feed(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, "Your post is live!")
            return redirect('posts:feed')
    else:
        form = PostForm()

    friend_ids = [f.id for f in FriendRequest.objects.friends_of(request.user)]
    friend_ids.append(request.user.id)
    posts = (
        Post.objects.filter(author_id__in=friend_ids)
        .select_related('author', 'author__profile')
        .prefetch_related('comments__author__profile', 'likes')
    )

    comment_form = CommentForm()

    return render(request, 'posts/feed.html', {
        'form': form,
        'posts': posts,
        'comment_form': comment_form,
    })


@login_required
def like_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    like, created = Like.objects.get_or_create(post=post, user=request.user)
    if not created:
        like.delete()
    else:
        notify(
            recipient=post.author,
            actor=request.user,
            verb='liked your post',
            target_url=reverse('posts:feed'),
        )
    return redirect(request.META.get('HTTP_REFERER') or 'posts:feed')


@login_required
def add_comment(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.save()
            notify(
                recipient=post.author,
                actor=request.user,
                verb='commented on your post',
                target_url=reverse('posts:feed'),
            )
    return redirect(request.META.get('HTTP_REFERER') or 'posts:feed')


@login_required
def delete_post(request, pk):
    post = get_object_or_404(Post, pk=pk, author=request.user)
    post.delete()
    messages.info(request, "Post deleted.")
    return redirect('posts:feed')


@login_required
def add_profile_comment(request, username):
    recipient = get_object_or_404(User, username=username)
    if request.method == 'POST':
        form = ProfileCommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.recipient = recipient
            comment.author = request.user
            comment.save()
            notify(
                recipient=recipient,
                actor=request.user,
                verb='left a comment on your profile',
                target_url=reverse('accounts:profile', kwargs={'username': username}),
            )
    return redirect('accounts:profile', username=username)


@login_required
def delete_profile_comment(request, pk):
    comment = get_object_or_404(ProfileComment, pk=pk)
    if request.user in (comment.author, comment.recipient):
        username = comment.recipient.username
        comment.delete()
        return redirect('accounts:profile', username=username)
    messages.error(request, "You can't delete that comment.")
    return redirect('posts:feed')
