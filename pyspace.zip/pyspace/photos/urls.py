from django.urls import path

from photos import views

app_name = 'photos'

urlpatterns = [
    path('user/<str:username>/', views.album_list, name='album_list'),
    path('new/', views.album_create, name='album_create'),
    path('album/<int:pk>/', views.album_detail, name='album_detail'),
    path('album/<int:pk>/delete/', views.album_delete, name='album_delete'),
    path('photo/<int:pk>/delete/', views.photo_delete, name='photo_delete'),
]
