from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render

from photos.forms import AlbumForm, PhotoUploadForm
from photos.models import Album, Photo


def album_list(request, username):
    owner = get_object_or_404(User, username=username)
    albums = Album.objects.filter(owner=owner)
    return render(request, 'photos/album_list.html', {
        'owner': owner,
        'albums': albums,
        'is_own': request.user.is_authenticated and request.user == owner,
    })


@login_required
def album_create(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            album = form.save(commit=False)
            album.owner = request.user
            album.save()
            messages.success(request, f'Album "{album.title}" created.')
            return redirect('photos:album_detail', pk=album.pk)
    else:
        form = AlbumForm()
    return render(request, 'photos/album_form.html', {'form': form})


def album_detail(request, pk):
    album = get_object_or_404(Album, pk=pk)
    is_owner = request.user.is_authenticated and request.user == album.owner

    upload_form = None
    if is_owner:
        if request.method == 'POST':
            upload_form = PhotoUploadForm(request.POST, request.FILES)
            if upload_form.is_valid():
                photo = upload_form.save(commit=False)
                photo.album = album
                photo.save()
                messages.success(request, "Photo uploaded.")
                return redirect('photos:album_detail', pk=album.pk)
        else:
            upload_form = PhotoUploadForm()

    return render(request, 'photos/album_detail.html', {
        'album': album,
        'photos': album.photos.all(),
        'is_owner': is_owner,
        'upload_form': upload_form,
    })


@login_required
def photo_delete(request, pk):
    photo = get_object_or_404(Photo, pk=pk, album__owner=request.user)
    album_pk = photo.album_id
    photo.delete()
    messages.info(request, "Photo deleted.")
    return redirect('photos:album_detail', pk=album_pk)


@login_required
def album_delete(request, pk):
    album = get_object_or_404(Album, pk=pk, owner=request.user)
    album.delete()
    messages.info(request, "Album deleted.")
    return redirect('photos:album_list', username=request.user.username)
