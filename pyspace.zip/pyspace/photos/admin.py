from django.contrib import admin

from photos.models import Album, Photo


class PhotoInline(admin.TabularInline):
    model = Photo
    extra = 0


@admin.register(Album)
class AlbumAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'created_at')
    inlines = [PhotoInline]


admin.site.register(Photo)
