from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse

from friends.models import FriendRequest
from friends.services import friendship_status
from notifications.utils import notify


@login_required
def friends_list(request, username=None):
    target = get_object_or_404(User, username=username) if username else request.user
    friends = FriendRequest.objects.friends_of(target)
    return render(request, 'friends/friends_list.html', {
        'target': target,
        'friends': friends,
        'is_own': target == request.user,
    })


@login_required
def friend_requests_inbox(request):
    received = FriendRequest.objects.pending_received(request.user)
    sent = FriendRequest.objects.pending_sent(request.user)
    return render(request, 'friends/requests_inbox.html', {
        'received': received,
        'sent': sent,
    })


@login_required
def send_friend_request(request, username):
    to_user = get_object_or_404(User, username=username)

    if to_user == request.user:
        messages.error(request, "You can't friend yourself!")
        return redirect('accounts:profile', username=username)

    status = friendship_status(request.user, to_user)
    if status is not None:
        messages.info(request, "There's already a friend request between you two.")
        return redirect('accounts:profile', username=username)

    FriendRequest.objects.create(from_user=request.user, to_user=to_user)
    notify(
        recipient=to_user,
        actor=request.user,
        verb='sent you a friend request',
        target_url=reverse('friends:inbox'),
    )
    messages.success(request, f"Friend request sent to {to_user.username}.")
    return redirect('accounts:profile', username=username)


@login_required
def respond_friend_request(request, pk, action):
    fr = get_object_or_404(FriendRequest, pk=pk, to_user=request.user)

    if action == 'accept':
        fr.status = FriendRequest.ACCEPTED
        fr.save(update_fields=['status'])
        notify(
            recipient=fr.from_user,
            actor=request.user,
            verb='accepted your friend request',
            target_url=reverse('accounts:profile', kwargs={'username': request.user.username}),
        )
        messages.success(request, f"You and {fr.from_user.username} are now friends!")
    elif action == 'decline':
        fr.status = FriendRequest.DECLINED
        fr.save(update_fields=['status'])
        messages.info(request, "Friend request declined.")

    return redirect('friends:inbox')


@login_required
def remove_friend(request, username):
    other = get_object_or_404(User, username=username)
    fr = FriendRequest.objects.between(request.user, other)
    if fr and fr.status == FriendRequest.ACCEPTED:
        fr.delete()
        messages.info(request, f"Removed {other.username} from your friends.")
    return redirect('accounts:profile', username=username)
