from django.urls import path

from friends import views

app_name = 'friends'

urlpatterns = [
    path('', views.friends_list, name='my_friends'),
    path('inbox/', views.friend_requests_inbox, name='inbox'),
    path('of/<str:username>/', views.friends_list, name='friends_list'),
    path('add/<str:username>/', views.send_friend_request, name='add'),
    path('respond/<int:pk>/<str:action>/', views.respond_friend_request, name='respond'),
    path('remove/<str:username>/', views.remove_friend, name='remove'),
]
