from friends.models import FriendRequest


def pending_friend_requests(request):
    if request.user.is_authenticated:
        count = FriendRequest.objects.pending_received(request.user).count()
        return {'pending_friend_request_count': count}
    return {'pending_friend_request_count': 0}
