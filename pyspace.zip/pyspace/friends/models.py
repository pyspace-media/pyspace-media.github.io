from django.conf import settings
from django.db import models
from django.db.models import Q


class FriendRequestManager(models.Manager):

    def pending_received(self, user):
        return self.filter(to_user=user, status=FriendRequest.PENDING).select_related(
            'from_user__profile'
        )

    def pending_sent(self, user):
        return self.filter(from_user=user, status=FriendRequest.PENDING)

    def accepted_for_user(self, user):
        return self.filter(
            Q(from_user=user) | Q(to_user=user), status=FriendRequest.ACCEPTED
        )

    def friends_of(self, user):
        """Return a list of Users who are friends with `user`."""
        accepted = self.accepted_for_user(user).select_related(
            'from_user__profile', 'to_user__profile'
        )
        result = []
        for fr in accepted:
            result.append(fr.to_user if fr.from_user_id == user.id else fr.from_user)
        return result

    def between(self, user_a, user_b):
        return self.filter(
            Q(from_user=user_a, to_user=user_b) | Q(from_user=user_b, to_user=user_a)
        ).first()


class FriendRequest(models.Model):
    PENDING = 'pending'
    ACCEPTED = 'accepted'
    DECLINED = 'declined'
    STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (ACCEPTED, 'Accepted'),
        (DECLINED, 'Declined'),
    ]

    from_user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_friend_requests'
    )
    to_user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='received_friend_requests'
    )
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)

    objects = FriendRequestManager()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['from_user', 'to_user'], name='unique_friend_request_pair'
            )
        ]
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.from_user} -> {self.to_user} ({self.status})"
