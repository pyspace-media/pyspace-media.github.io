"""Small helper functions for working out friendship state between two users."""

from friends.models import FriendRequest


def are_friends(user_a, user_b):
    fr = FriendRequest.objects.between(user_a, user_b)
    return bool(fr and fr.status == FriendRequest.ACCEPTED)


def friendship_status(user, other):
    """
    Returns one of: 'friends', 'pending_sent', 'pending_received', or None
    (None means no relationship exists yet, and a request can be sent).
    """
    fr = FriendRequest.objects.between(user, other)
    if not fr or fr.status == FriendRequest.DECLINED:
        return None
    if fr.status == FriendRequest.ACCEPTED:
        return 'friends'
    if fr.status == FriendRequest.PENDING:
        return 'pending_sent' if fr.from_user_id == user.id else 'pending_received'
    return None
