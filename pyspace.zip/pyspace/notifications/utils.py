from notifications.models import Notification


def notify(recipient, verb, actor=None, target_url=''):
    """
    Create a notification, unless the user would just be notifying themselves.
    """
    if actor and actor == recipient:
        return None
    return Notification.objects.create(
        recipient=recipient, actor=actor, verb=verb, target_url=target_url
    )
