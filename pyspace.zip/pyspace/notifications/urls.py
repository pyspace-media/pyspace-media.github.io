from django.urls import path

from notifications import views

app_name = 'notifications'

urlpatterns = [
    path('', views.notification_list, name='list'),
    path('go/<int:pk>/', views.notification_redirect, name='go'),
]
